package com.example.server.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author c
 * @since 2023-03-30
 */
@RestController
@RequestMapping("/sys-msg")
public class SysMsgController {

}
